import React, { useEffect, useRef, useState } from 'react'

export default function App(){
  const [screen, setScreen] = useState('splash') // splash | lobby | rps | guess | ttt | pong
  const [serverUrl, setServerUrl] = useState('ws://localhost:9000')
  const [connected, setConnected] = useState(false)
  const [ping, setPing] = useState('-')
  const [rooms, setRooms] = useState([])
  const [chat, setChat] = useState([])
  const wsRef = useRef(null)
  const nameRef = useRef('Player'+Math.floor(Math.random()*1000))

  // connect
  const connect = ()=>{
    const ws = new WebSocket(serverUrl)
    wsRef.current = ws
    ws.onopen = ()=>{ setConnected(true); send({type:'SET_NAME', name:nameRef.current}); }
    ws.onclose = ()=> setConnected(false)
    ws.onmessage = (ev)=>{
      const m = JSON.parse(ev.data||'{}')
      if(m.type==='PONG' && window.__t0) setPing(Math.round(performance.now()-window.__t0)+'ms')
      if(m.type==='ROOMS') setRooms(m.list||[])
      if(m.type==='ROOM_CREATED') pushChat('System', 'Room '+m.id+' created')
      if(m.type==='JOINED') pushChat('System', 'Joined room '+m.id+' (peers: '+m.peers+')')
      if(m.type==='ROOM_UPDATE') pushChat('System', 'Peers: '+m.peers)
      if(m.type==='CHAT') pushChat(m.from, m.msg)
      if(m.type==='RPS_RESULT') setRpsResult(`P1: ${m.p1} • P2: ${m.p2} • ${m.winner}`)
      if(m.type==='GUESS_RESULT') pushChat('Guess', `${m.from} đoán ${m.value} → ${m.result}`)
      if(m.type==='TTT_STATE'){ setTttBoard(m.board); setTttTurn(m.turn); setTttWin(m.win||'') }
      if(m.type==='GAME_CHANGED'){ pushChat('System', `Game switched to ${m.game}`) }
    }
  }

  const send = (o)=>{ const ws = wsRef.current; if(ws && ws.readyState===1) ws.send(JSON.stringify(o)) }
  const pushChat = (from, msg)=> setChat(x=>[...x, {from, msg, ts:Date.now()}])
  const reqRooms = ()=>{ send({type:'LIST_ROOMS'}); window.__t0 = performance.now(); send({type:'PING', t:window.__t0}); }
  const createRoom = ()=> send({type:'CREATE_ROOM'})
  const joinRoom = (id)=> send({type:'JOIN_ROOM', id})
  const setGame = (g)=> send({type:'SET_GAME', game:g})

  // RPS
  const [rpsResult, setRpsResult] = useState('')
  const rpsPick = (c)=>{ setRpsResult('Đang chờ...'); send({type:'RPS_CHOICE', choice:c}) }

  // Guess
  const [guess, setGuess] = useState('')
  const doGuess = ()=>{ const v = parseInt(guess||'0',10); if(Number.isFinite(v)) send({type:'GUESS', value:v}); setGuess('') }

  // TTT
  const [tttBoard, setTttBoard] = useState(Array(9).fill(''))
  const [tttTurn, setTttTurn] = useState('X')
  const [tttWin, setTttWin] = useState('')
  const tttMove = (i)=> send({type:'TTT_MOVE', index:i})

  return (
    <div>
      <div className="header">
        <div className="container header-inner">
          <div className="title">MiniGame Pro <span className="badge">React</span></div>
          <div className="grid" style={{gridTemplateColumns:'320px auto auto', gap:12}}>
            <input className="input" value={serverUrl} onChange={e=>setServerUrl(e.target.value)} placeholder="ws://localhost:9000" />
            <button className={`btn ${connected?'btn-accent pulse':'btn-secondary'}`} onClick={connect}>{connected?'Connected':'Connect'}</button>
            <span className="badge">Ping: {ping}</span>
          </div>
        </div>
      </div>

      {/* Splash */}
      {screen==='splash' && (
        <div className="container">
          <div className="gradient-anim float-anim" style={{marginTop:32, textAlign:'center'}}>
            <h1 style={{margin:'8px 0'}}>Splash</h1>
            <p>Chọn chế độ để bắt đầu. Bạn có thể chuyển game tại Lobby.</p>
            <div style={{display:'flex', gap:12, justifyContent:'center', marginTop:16}}>
              <button className="btn btn-accent" onClick={()=>{ setScreen('lobby'); reqRooms(); }}>Play Online (Lobby)</button>
              <button className="btn btn-secondary" onClick={()=> setScreen('rps')}>RPS</button>
              <button className="btn btn-secondary" onClick={()=> setScreen('guess')}>Guess Number</button>
            </div>
          </div>
        </div>
      )}

      {/* Lobby */}
      {screen==='lobby' && (
        <div className="container">
          <div className="grid grid-2">
            <div className="card">
              <div style={{display:'flex', gap:8, marginBottom:8}}>
                <button className="btn btn-accent" onClick={createRoom}>Create Room</button>
                <button className="btn btn-secondary" onClick={reqRooms}>Refresh</button>
                <button className="btn btn-secondary" onClick={()=> setScreen('splash')}>Back</button>
              </div>
              <table className="table">
                <thead><tr><th>ID</th><th>Players</th><th>Status</th></tr></thead>
                <tbody>
                  {rooms.map(r=> (
                    <tr key={r.id} onClick={()=> joinRoom(r.id)} style={{cursor:'pointer'}}>
                      <td>{r.id}</td><td>{r.players}</td><td>{r.status||'Wait'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div style={{display:'flex', gap:8, marginTop:12}}>
                <span className="badge">Switch game:</span>
                <button className="btn btn-secondary" onClick={()=> setGame('rps')}>RPS</button>
                <button className="btn btn-secondary" onClick={()=> setGame('guess')}>Guess</button>
                <button className="btn btn-secondary" onClick={()=> setGame('ttt')}>TicTacToe</button>
              </div>
            </div>

            <div className="card">
              <div style={{display:'flex', gap:8, marginBottom:8}}>
                <input className="input" placeholder="Your name" defaultValue={nameRef.current} onChange={e=>nameRef.current=e.target.value} />
                <input className="input" id="chatmsg" placeholder="Message..." />
                <button className="btn btn-secondary" onClick={()=>{ const v=document.getElementById('chatmsg').value.trim(); if(!v) return; send({type:'CHAT', msg:v}); document.getElementById('chatmsg').value=''; }}>Send</button>
              </div>
              <div className="chatbox">
                {chat.map((c,i)=> (<div key={i}><small>[{new Date(c.ts).toLocaleTimeString()}]</small> <b>{c.from}:</b> {c.msg}</div>))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* RPS */}
      {screen==='rps' && (
        <div className="container">
          <div className="card" style={{textAlign:'center'}}>
            <h2>Rock • Paper • Scissors</h2>
            <div style={{display:'flex', gap:12, justifyContent:'center', margin:'12px 0'}}>
              <button className="btn btn-accent" onClick={()=> rpsPick('rock')}>✊ Rock</button>
              <button className="btn btn-accent" onClick={()=> rpsPick('paper')}>✋ Paper</button>
              <button className="btn btn-accent" onClick={()=> rpsPick('scissors')}>✌ Scissors</button>
            </div>
            <div className="badge">{rpsResult}</div>
            <div style={{marginTop:12}}><button className="btn btn-secondary" onClick={()=> setScreen('lobby')}>Back to Lobby</button></div>
          </div>
        </div>
      )}

      {/* Guess Number */}
      {screen==='guess' && (
        <div className="container">
          <div className="card" style={{textAlign:'center'}}>
            <h2>Guess Number (1..100)</h2>
            <div style={{display:'flex', gap:8, justifyContent:'center'}}>
              <input className="input" style={{width:120}} value={guess} onChange={e=>setGuess(e.target.value)} placeholder="Your guess"/>
              <button className="btn btn-accent" onClick={doGuess}>Send</button>
            </div>
            <div style={{marginTop:12}}><button className="btn btn-secondary" onClick={()=> setScreen('lobby')}>Back to Lobby</button></div>
          </div>
        </div>
      )}

      {/* TicTacToe (local render, WS-managed state) */}
      {screen==='ttt' && (
        <div className="container">
          <div className="card" style={{textAlign:'center'}}>
            <h2>TicTacToe</h2>
            <div style={{display:'grid', gridTemplateColumns:'repeat(3, 80px)', gap:6, justifyContent:'center', margin:'12px auto'}}>
              {tttBoard.map((v,i)=> (
                <button key={i} className="btn btn-secondary" style={{height:80, fontSize:28}} onClick={()=> tttMove(i)}>{v}</button>
              ))}
            </div>
            <div className="badge">Turn: {tttTurn} {tttWin && `• Winner: ${tttWin}`}</div>
            <div style={{marginTop:12}}><button className="btn btn-secondary" onClick={()=> setScreen('lobby')}>Back to Lobby</button></div>
          </div>
        </div>
      )}

      {/* Pong (demo offline canvas) */}
      {screen==='pong' && <Pong onBack={()=> setScreen('lobby')} />}

      {/* Quick nav */}
      <div className="container" style={{marginTop:18}}>
        <div className="card" style={{display:'flex', gap:8, justifyContent:'center'}}>
          <button className="btn btn-secondary" onClick={()=> setScreen('splash')}>Splash</button>
          <button className="btn btn-secondary" onClick={()=> { setScreen('lobby'); reqRooms(); }}>Lobby</button>
          <button className="btn btn-secondary" onClick={()=> setScreen('rps')}>RPS</button>
          <button className="btn btn-secondary" onClick={()=> setScreen('guess')}>Guess</button>
          <button className="btn btn-secondary" onClick={()=> setScreen('ttt')}>TTT</button>
          <button className="btn btn-secondary" onClick={()=> setScreen('pong')}>Pong (demo)</button>
        </div>
      </div>
    </div>
  )
}

function Pong({ onBack }){
  const ref = React.useRef(null)
  const anim = React.useRef(0)
  React.useEffect(()=>{
    const canvas = ref.current; const ctx = canvas.getContext('2d')
    const W = canvas.width, H = canvas.height
    const s = { bx:W/2, by:H/2, vx:3, vy:2, p1:H/2, p2:H/2, s1:0, s2:0 }
    const onMove = e => { const r = canvas.getBoundingClientRect(); s.p1 = e.clientY - r.top }
    window.addEventListener('mousemove', onMove)

    function loop(){
      s.bx+=s.vx; s.by+=s.vy
      if(s.by<10||s.by>H-10) s.vy*=-1
      // simple AI
      s.p2 += Math.sign(s.by - s.p2)*2.2
      // collide
      if(s.bx<20 && Math.abs(s.by - s.p1)<40) s.vx = Math.abs(s.vx)
      if(s.bx>W-20 && Math.abs(s.by - s.p2)<40) s.vx = -Math.abs(s.vx)
      if(s.bx<0){ s.s2++; s.bx=W/2; s.by=H/2; s.vx=3; s.vy=2*(Math.random()>0.5?1:-1) }
      if(s.bx>W){ s.s1++; s.bx=W/2; s.by=H/2; s.vx=-3; s.vy=2*(Math.random()>0.5?1:-1) }

      // draw
      ctx.fillStyle='#0f172a'; ctx.fillRect(0,0,W,H)
      ctx.fillStyle='#e5e7eb'
      for(let y=0;y<H;y+=16) ctx.fillRect(W/2-1, y, 2, 8)
      ctx.fillRect(8, s.p1-40, 8, 80)
      ctx.fillRect(W-16, s.p2-40, 8, 80)
      ctx.beginPath(); ctx.arc(s.bx, s.by, 8, 0, Math.PI*2); ctx.fill()
      ctx.font='16px monospace'; ctx.fillText(`${s.s1} : ${s.s2}`, W/2-16, 20)
      anim.current = requestAnimationFrame(loop)
    }
    anim.current = requestAnimationFrame(loop)
    return ()=>{ cancelAnimationFrame(anim.current); window.removeEventListener('mousemove', onMove) }
  },[])

  return (
    <div className="container">
      <div className="card" style={{textAlign:'center'}}>
        <h2>Classic Pong (demo offline)</h2>
        <canvas ref={ref} width={640} height={360} style={{border:'1px solid #334', borderRadius:16}}/>
        <div style={{marginTop:12}}><button className="btn btn-secondary" onClick={onBack}>Back</button></div>
      </div>
    </div>
  )
}
