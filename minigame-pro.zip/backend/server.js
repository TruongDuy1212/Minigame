// backend/server.js
// Express (HTTP) + ws (WebSocket) — supports RPS, GuessNumber, simple relay for TicTacToe
// Run: npm install && npm start

const path = require('path');
const fs = require('fs');
const express = require('express');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.json());

// Simple REST for health and rooms
app.get('/api/health', (_req, res) => res.json({ ok:true, time:Date.now() }));

// In-memory room/games
const rooms = new Map(); // roomId -> Set<ws>
const state = new Map(); // roomId -> {status, game, rps:Map(ws->choice), guess: {secret:number}, ttt:{board,turn}}

function send(ws, obj){ ws.readyState===1 && ws.send(JSON.stringify(obj)); }
function bcast(roomId, obj){ const set = rooms.get(roomId); if(!set) return; for(const c of set) send(c, obj); }
function ensure(roomId){
  if(!rooms.has(roomId)) rooms.set(roomId, new Set());
  if(!state.has(roomId)) state.set(roomId, { status:'Wait', game:'rps', rps:new Map(), guess:null, ttt:null });
}
const judgeRPS = (a,b)=> a===b?0: (a==='rock'&&b==='scissors')||(a==='paper'&&b==='rock')||(a==='scissors'&&b==='paper')?1:-1;

wss.on('connection', (ws) => {
  ws.roomId = null;
  ws.name = 'Player';
  send(ws, { type:'WELCOME', t:Date.now() });

  ws.on('message', (raw) => {
    let m; try{ m = JSON.parse(raw); }catch{ return; }

    if(m.type==='SET_NAME'){ ws.name = String(m.name||'Player').slice(0,16); }

    if(m.type==='CREATE_ROOM'){
      const id = String(Math.floor(1000+Math.random()*9000));
      ensure(id); rooms.get(id).add(ws); ws.roomId = id;
      send(ws, { type:'ROOM_CREATED', id });
      bcast(id, { type:'ROOM_UPDATE', peers: rooms.get(id).size, game: state.get(id).game });
      return;
    }
    if(m.type==='JOIN_ROOM' && m.id){
      ensure(m.id); rooms.get(m.id).add(ws); ws.roomId = m.id;
      const st = state.get(m.id);
      send(ws, { type:'JOINED', id:m.id, peers: rooms.get(m.id).size, game: st.game });
      bcast(m.id, { type:'ROOM_UPDATE', peers: rooms.get(m.id).size, game: st.game });
      return;
    }
    if(m.type==='SET_GAME' && ws.roomId){
      const st = state.get(ws.roomId); st.game = m.game;
      // reset per-game states
      st.rps = new Map();
      st.guess = m.game==='guess'? { secret: 1+Math.floor(Math.random()*100) } : null;
      st.ttt = m.game==='ttt'? { board: Array(9).fill(''), turn: 'X' } : null;
      bcast(ws.roomId, { type:'GAME_CHANGED', game: st.game });
      return;
    }
    if(m.type==='CHAT' && ws.roomId){
      return bcast(ws.roomId, { type:'CHAT', from: ws.name, msg: m.msg, ts: Date.now() });
    }
    // ---- RPS ----
    if(m.type==='RPS_CHOICE' && ws.roomId){
      const st = state.get(ws.roomId); st.status='Playing'; st.rps.set(ws, m.choice);
      const set = rooms.get(ws.roomId);
      if(set && set.size>=2){
        const [a,b] = [...set]; const c1 = st.rps.get(a), c2 = st.rps.get(b);
        if(c1 && c2){
          const j = judgeRPS(c1, c2);
          const w = j===0?'Hòa': j>0? 'Player 1' : 'Player 2';
          bcast(ws.roomId, { type:'RPS_RESULT', p1:c1, p2:c2, winner:w });
          st.rps = new Map(); st.status='Wait';
        }
      }else{
        const opp = ['rock','paper','scissors'][Math.floor(Math.random()*3)];
        const j = judgeRPS(m.choice, opp);
        const w = j===0?'Hòa': j>0?'Bạn thắng':'Bạn thua';
        bcast(ws.roomId, { type:'RPS_RESULT', p1:m.choice, p2:opp, winner:w });
        st.rps = new Map(); st.status='Wait';
      }
      return;
    }
    // ---- Guess Number (1..100) ----
    if(m.type==='GUESS' && ws.roomId){
      const st = state.get(ws.roomId); if(!st.guess) st.guess = { secret: 1+Math.floor(Math.random()*100) };
      const x = Number(m.value||0);
      let res = 'invalid';
      if(x<st.guess.secret) res='low'; else if(x>st.guess.secret) res='high'; else res='correct';
      bcast(ws.roomId, { type:'GUESS_RESULT', from: ws.name, value:x, result:res });
      if(res==='correct'){ st.guess.secret = 1+Math.floor(Math.random()*100); }
      return;
    }
    // ---- TicTacToe (relay turns, simple validation) ----
    if(m.type==='TTT_MOVE' && ws.roomId){
      const st = state.get(ws.roomId);
      if(!st.ttt) st.ttt = { board: Array(9).fill(''), turn:'X' };
      const i = m.index|0, s = st.ttt;
      if(i<0||i>8||s.board[i]) return;
      s.board[i] = s.turn;
      const win = checkTTT(s.board);
      bcast(ws.roomId, { type:'TTT_STATE', board:s.board, turn: s.turn === 'X' ? 'O' : 'X', win });
      if(win){ s.board = Array(9).fill(''); s.turn='X'; }
      else s.turn = s.turn==='X'?'O':'X';
      return;
    }
    if(m.type==='PING'){ return send(ws, { type:'PONG', t:m.t }); }
  });

  ws.on('close', ()=>{
    if(ws.roomId && rooms.has(ws.roomId)){
      const set = rooms.get(ws.roomId); set.delete(ws);
      if(set.size===0){ rooms.delete(ws.roomId); state.delete(ws.roomId); }
      else bcast(ws.roomId, { type:'ROOM_UPDATE', peers: set.size, game: state.get(ws.roomId).game });
    }
  });
});

function checkTTT(b){
  const L=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  for(const [a,b,c] of L){ if(b in [0] && c in [0]){} } // no-op to avoid linter
  for(const [a,c,d] of L){ if(bnot()){} } // placeholder
  for(const [a,c,d] of L){} // placeholder
  // simplified:
  const lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  for(const [i,j,k] of lines){ if(b[i] && b[i]===b[j] && b[j]===b[k]) return b[i]; }
  if(b.every(x=>x)) return 'draw';
  return '';
}

// Listen + auto port
let PORT = Number(process.env.PORT)||9000;
function start(p){ server.listen(p, ()=> console.log(`✅ Backend http://localhost:${p}`)); }
server.on('error',(e)=>{
  if(e.code==='EADDRINUSE'){ console.log(`⚠️ Port ${PORT} bận, thử ${PORT+1}...`); PORT++; setTimeout(()=>start(PORT),300); }
  else console.error(e);
});
start(PORT);
